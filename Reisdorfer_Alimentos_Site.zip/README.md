
# Reisdorfer Alimentos - Catálogo Online

Este é o site da Reisdorfer Alimentos, dedicado à exibição de nossos produtos, incluindo carnes, frios, laticínios e muito mais.

## Funcionalidades:

- Catálogo de produtos com informações detalhadas como código de barras, preço, NCM, e descrição.
- Pesquisa de produtos.
- Informações de contato para dúvidas ou pedidos.

## Como Usar:

Basta navegar pelas categorias de produtos para visualizar todos os itens disponíveis.

## Licença:

Distribuído sob a licença MIT.
    